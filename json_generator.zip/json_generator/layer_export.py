# layer_export.py
#
# Export layer JSON for a portal from LayerConfig_v3.db
# Uses:
#   Portals
#   PortalLayers
#   ServiceLayers
#   MapServerLayers
#   ServiceLayerFields
#   ServiceLayerStyles
#   PortalSwitchLayers
#   PortalSwitchLayerChildren

import json
import sqlite3
from typing import Dict, Any, List, Optional


def _get_portal_id(conn: sqlite3.Connection, portal_key: str) -> int:
    cur = conn.execute(
        "SELECT PortalId FROM Portals WHERE PortalKey = ?", (portal_key,)
    )
    row = cur.fetchone()
    if not row:
        raise ValueError(f"PortalKey '{portal_key}' not found in Portals")
    return row[0]


def _load_switch_layers(
    conn: sqlite3.Connection, portal_id: int
) -> Dict[str, Dict[str, Any]]:
    """
    Returns mapping:
        switchKey -> {
            "vectorFeaturesMinScale": int | None,
            "childrenLayerKeys": [layerKey, ...]
        }
    """
    # PortalSwitchLayers is per portal
    cur = conn.execute(
        """
        SELECT
            psl.PortalSwitchLayerId,
            psl.SwitchKey,
            psl.VectorFeaturesMinScale
        FROM PortalSwitchLayers psl
        WHERE psl.PortalId = ?
        """,
        (portal_id,),
    )
    switch_rows = cur.fetchall()

    result: Dict[str, Dict[str, Any]] = {}
    if not switch_rows:
        return result

    # Map switchId -> (switchKey, minScale)
    switch_by_id = {
        row[0]: {
            "switchKey": row[1],
            "vectorFeaturesMinScale": row[2],
        }
        for row in switch_rows
    }

    # Children
    cur = conn.execute(
        """
        SELECT
            pslc.PortalSwitchLayerId,
            sl.LayerKey,
            pslc.ChildOrder
        FROM PortalSwitchLayerChildren pslc
        JOIN ServiceLayers sl
          ON sl.ServiceLayerId = pslc.ServiceLayerId
        JOIN PortalSwitchLayers psl
          ON psl.PortalSwitchLayerId = pslc.PortalSwitchLayerId
        WHERE psl.PortalId = ?
        """,
        (portal_id,),
    )
    children_rows = cur.fetchall()

    children_by_switch_id: Dict[int, List[str]] = {}
    for switch_id, layer_key, child_order in children_rows:
        children_by_switch_id.setdefault(switch_id, []).append((child_order, layer_key))

    for switch_id, meta in switch_by_id.items():
        children_pairs = children_by_switch_id.get(switch_id, [])
        children_keys = [lk for _, lk in sorted(children_pairs, key=lambda x: x[0] or 0)]
        result[meta["switchKey"]] = {
            "vectorFeaturesMinScale": meta["vectorFeaturesMinScale"],
            "childrenLayerKeys": children_keys,
        }

    return result


def _load_portal_service_layers(
    conn: sqlite3.Connection, portal_id: int
) -> List[Dict[str, Any]]:
    """
    Returns a list of dicts for all ServiceLayers that belong to this portal
    via PortalLayers, joined with MapServerLayers.
    """
    cur = conn.execute(
        """
        SELECT
            sl.ServiceLayerId,
            sl.LayerKey,
            sl.ServiceType,
            sl.FeatureType,
            sl.IdPropertyName,
            sl.GeomFieldName,
            sl.LabelClassName,
            sl.Opacity,
            sl.OpenLayersJson,
            sl.ServerOptionsJson,
            sl.GridXType,
            sl.ProjectionOverride,
            sl.OpacityOverride,
            sl.NoClusterOverride,
            sl.FeatureInfoWindowOverride,
            sl.Grouping,
            sl.IsUserConfigurable,
            m.MapServerLayerId,
            m.MapLayerName,
            m.BaseLayerKey,
            m.GridXType AS MapGridXType,
            m.GeometryType,
            m.DefaultGeomFieldName,
            m.DefaultLabelClassName,
            m.DefaultOpacity
        FROM PortalLayers pl
        JOIN ServiceLayers sl
          ON sl.ServiceLayerId = pl.ServiceLayerId
        JOIN MapServerLayers m
          ON m.MapServerLayerId = sl.MapServerLayerId
        WHERE pl.PortalId = ?
          AND pl.IsEnabled = 1
        ORDER BY sl.LayerKey
        """,
        (portal_id,),
    )

    rows = []
    cols = [d[0] for d in cur.description]
    for r in cur.fetchall():
        rows.append(dict(zip(cols, r)))
    return rows


def _load_service_fields(
    conn: sqlite3.Connection, service_layer_id: int
) -> List[Dict[str, Any]]:
    """
    ServiceLayerFields: per-service propertynames & tooltips.
    """
    cur = conn.execute(
        """
        SELECT
            FieldName,
            FieldType,
            IncludeInPropertyname,
            IsTooltip,
            TooltipAlias,
            FieldOrder
        FROM ServiceLayerFields
        WHERE ServiceLayerId = ?
        ORDER BY COALESCE(FieldOrder, 0), FieldName
        """,
        (service_layer_id,),
    )
    rows = []
    cols = [d[0] for d in cur.description]
    for r in cur.fetchall():
        rows.append(dict(zip(cols, r)))
    return rows


def _load_service_styles(
    conn: sqlite3.Connection, service_layer_id: int
) -> List[Dict[str, Any]]:
    """
    ServiceLayerStyles: per-service style list, with UseLabelRule flag.
    """
    cur = conn.execute(
        """
        SELECT
            StyleName,
            StyleTitle,
            UseLabelRule,
            StyleOrder
        FROM ServiceLayerStyles
        WHERE ServiceLayerId = ?
        ORDER BY COALESCE(StyleOrder, 0), StyleName
        """,
        (service_layer_id,),
    )
    rows = []
    cols = [d[0] for d in cur.description]
    for r in cur.fetchall():
        rows.append(dict(zip(cols, r)))
    return rows


def build_portal_layer_model(
    conn: sqlite3.Connection, portal_key: str
) -> Dict[str, Any]:
    """
    Canonical in-memory model for all layers in a portal.
    Structure:
      {
        "portalKey": ...,
        "layers": { layerKey -> layerInfo },
        "switchLayers": { switchKey -> switchInfo }
      }
    """
    portal_id = _get_portal_id(conn, portal_key)
    svc_rows = _load_portal_service_layers(conn, portal_id)
    switch_map = _load_switch_layers(conn, portal_id)

    layers: Dict[str, Any] = {}

    for row in svc_rows:
        layer_key = row["LayerKey"]
        service_layer_id = row["ServiceLayerId"]

        # Base defaults
        default_label = row["DefaultLabelClassName"] or "labels"
        default_opacity = row["DefaultOpacity"] if row["DefaultOpacity"] is not None else 0.75
        default_geom_field = row["DefaultGeomFieldName"] or "msGeometry"

        # Effective values with overrides
        projection = row["ProjectionOverride"]  # you can later plug global default if None
        opacity = row["OpacityOverride"] if row["OpacityOverride"] is not None else default_opacity
        no_cluster = None
        if row["NoClusterOverride"] is not None:
            no_cluster = bool(row["NoClusterOverride"])

        # Fields
        service_fields = _load_service_fields(conn, service_layer_id)
        property_names = [
            f["FieldName"]
            for f in service_fields
            if f.get("IncludeInPropertyname")
        ]
        tooltips = [
            {
                "field": f["FieldName"],
                "alias": f.get("TooltipAlias") or f["FieldName"],
            }
            for f in service_fields
            if f.get("IsTooltip")
        ]
        # If IdPropertyName is NULL, exporter can fall back to first property or MapServerLayerFields later.
        id_prop = row["IdPropertyName"]

        # Styles
        service_styles = _load_service_styles(conn, service_layer_id)
        styles = []
        for s in service_styles:
            style_entry: Dict[str, Any] = {
                "name": s["StyleName"],
                "title": s["StyleTitle"],
            }
            # For WFS, UseLabelRule controls labelRule
            if row["ServiceType"].upper() == "WFS" and s.get("UseLabelRule"):
                style_entry["labelRule"] = default_label
            styles.append(style_entry)

        # Pack into model
        layers[layer_key] = {
            "layerKey": layer_key,
            "serviceType": row["ServiceType"].upper(),
            "mapLayerName": row["MapLayerName"],
            "geometryType": row["GeometryType"],
            "gridXType": row["GridXType"] or row["MapGridXType"],
            "defaults": {
                "labelClassName": default_label,
                "opacity": default_opacity,
                "geomFieldName": default_geom_field,
            },
            "overrides": {
                "projection": projection,
                "opacity": opacity if opacity != default_opacity else None,
                "noCluster": no_cluster,
            },
            "fields": {
                "idProperty": id_prop,
                "propertyNames": property_names,
                "tooltips": tooltips,
            },
            "styles": styles,
        }

    return {
        "portalKey": portal_key,
        "layers": layers,
        "switchLayers": switch_map,
    }


def export_portal_layer_json(
    conn: sqlite3.Connection,
    portal_key: str,
    output_path: str,
) -> None:
    """
    High-level exporter: build model and write JSON file.
    For now, we keep a simple shape:

    {
      "portalKey": "...",
      "layers": {
        "ROADSCHEDULENATIONAL_WMS": { ... },
        ...
      },
      "switchLayers": {
        "LIGHT_UNIT_SWITCH_LAYER": {
          "vectorFeaturesMinScale": 50000,
          "childrenLayerKeys": [...]
        }
      }
    }

    You can adjust this to exactly match your production default.json structure once
    you've diffed a few examples.
    """
    model = build_portal_layer_model(conn, portal_key)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(model, f, ensure_ascii=False, indent=2)
        f.write("\n")
